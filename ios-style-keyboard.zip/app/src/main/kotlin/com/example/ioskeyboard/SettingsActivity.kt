package com.example.ioskeyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {
    private lateinit var p: Prefs

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(40))
        }

        col.addView(TextView(this).apply {
            text = "iOS Style Keyboard"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD
        })

        col.addView(header("Set up"))
        col.addView(button("1. Enable keyboard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        col.addView(button("2. Select keyboard") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        col.addView(button("3. Allow microphone (voice typing)") { requestMic() })

        col.addView(header("Appearance"))
        val rg = RadioGroup(this)
        listOf("System" to "system", "Light" to "light", "Dark" to "dark").forEach { (label, v) ->
            rg.addView(RadioButton(this).apply {
                text = label
                id = View.generateViewId()
                isChecked = p.theme == v
                setOnClickListener { p.theme = v }
            })
        }
        col.addView(rg)

        col.addView(header("Keyboard adjustments"))
        val hLabel = TextView(this).apply { text = "Keyboard height: ${p.heightPct}%" }
        col.addView(hLabel)
        col.addView(SeekBar(this).apply {
            max = 50
            progress = p.heightPct - 80
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    p.heightPct = 80 + v
                    hLabel.text = "Keyboard height: ${80 + v}%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        col.addView(TextView(this).apply { text = "One-handed mode" })
        val oh = listOf("off", "left", "right")
        col.addView(spinner(listOf("Off", "Left hand", "Right hand"), oh.indexOf(p.oneHanded).coerceAtLeast(0)) {
            p.oneHanded = oh[it]
        })
        col.addView(toggle("Key sounds (iOS-style, synthesized)", { p.sound }, { p.sound = it }))
        col.addView(toggle("Use sounds cut from the supplied recording (off = synthesized)", { p.soundClip }, { p.soundClip = it }))
        col.addView(toggle("Haptic feedback", { p.haptic }, { p.haptic = it }))
        col.addView(toggle("Auto-capitalization", { p.autoCap }, { p.autoCap = it }))
        col.addView(toggle("Auto-correction", { p.autoCorrect }, { p.autoCorrect = it }))

        col.addView(header("Predictions"))
        col.addView(toggle("Online predictions (sends your last ~3 typed words to Google when online)",
            { p.cloud }, { p.cloud = it }))
        col.addView(TextView(this).apply {
            text = "Never used in password fields. Turn off to stay fully offline."
            textSize = 12f
        })

        col.addView(header("Voice typing language"))
        val langs = listOf(
            "Device default" to "", "English (US)" to "en-US", "Filipino" to "fil-PH",
            "Spanish" to "es-ES", "Japanese" to "ja-JP", "Korean" to "ko-KR",
            "Hindi" to "hi-IN", "Chinese (Mandarin)" to "zh-CN"
        )
        col.addView(spinner(langs.map { it.first }, langs.indexOfFirst { it.second == p.voiceLang }.coerceAtLeast(0)) {
            p.voiceLang = langs[it].second
        })

        col.addView(header("Try it"))
        col.addView(EditText(this).apply { hint = "Type here…"; minLines = 3 })

        setContentView(ScrollView(this).apply { addView(col) })
        if (intent.getBooleanExtra("ask_mic", false)) requestMic()
    }

    private fun requestMic() = requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)

    private fun header(t: String) = TextView(this).apply {
        text = t.uppercase(); textSize = 13f; setTextColor(0xFF6B6B6B.toInt())
        setPadding(0, dp(24), 0, dp(6))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun toggle(label: String, get: () -> Boolean, set: (Boolean) -> Unit) = Switch(this).apply {
        text = label; isChecked = get()
        setPadding(0, dp(10), 0, dp(10))
        setOnCheckedChangeListener { _, b -> set(b) }
    }

    private fun spinner(labels: List<String>, sel: Int, pick: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, labels)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { pick(pos) }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
    }
}
