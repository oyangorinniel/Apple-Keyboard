package com.example.ioskeyboard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class KeyboardService : InputMethodService(), KbHost {

    private class Revert(val orig: String, val fixed: String)

    private lateinit var prefs: Prefs
    private lateinit var engine: SuggestionEngine
    private lateinit var sounds: KeySounds
    private var soundClipLoaded = true
    private val translator by lazy { EnglishTranslator() }
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var kb: KbView? = null
    private var builtSig = ""
    private var lastSpace = 0L
    private var suggestToken = 0
    private var cloudJob: Runnable? = null
    private var detectedLang: String? = null
    private var revert: Revert? = null

    private var lastPrefix = ""
    private var lastCands: List<String> = emptyList()
    private var lastCorr: String? = null

    private var listening = false
    private var recognizer: SpeechRecognizer? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        engine = SuggestionEngine(this)
        soundClipLoaded = prefs.soundClip
        sounds = KeySounds(this, soundClipLoaded)
    }

    private fun buildView(): View {
        builtSig = prefs.signature()
        val v = KbView(this, this)
        v.configure(prefs.isDark(), prefs.heightPct, prefs.oneHanded)
        kb = v
        return v
    }

    override fun onCreateInputView(): View = buildView()

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (kb == null || builtSig != prefs.signature()) setInputView(buildView())
        if (prefs.soundClip != soundClipLoaded) {
            sounds.release()
            soundClipLoaded = prefs.soundClip
            sounds = KeySounds(this, soundClipLoaded)
        }
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        kb?.setMode(if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 1 else 0)
        kb?.shift = 0
        revert = null
        showTranslate(null)
        scheduleRefresh()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopVoice()
        engine.save()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        scheduleRefresh()
    }

    override fun onDestroy() {
        stopVoice()
        engine.save()
        sounds.release()
        io.shutdownNow()
        translator.close()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- KbHost: sound / haptics

    override fun onSound(kind: Int) { if (prefs.sound) sounds.play(kind) }

    override fun onHaptic() { if (prefs.haptic) kb?.haptic() }

    // ---------------------------------------------------------------- KbHost: typing

    override fun onChar(s: String) {
        val ic = currentInputConnection ?: return
        revert = null
        if (!s[0].isLetter() && s != "'" && s != "’") finishWord()
        ic.commitText(s, 1)
        scheduleRefresh()
    }

    override fun onBackspace(word: Boolean) {
        val ic = currentInputConnection ?: return
        revert = null
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else if (word) {
            val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
            if (before.isEmpty()) return
            var i = before.length
            while (i > 0 && before[i - 1].isWhitespace()) i--
            while (i > 0 && !before[i - 1].isWhitespace()) i--
            ic.deleteSurroundingText(before.length - i, 0)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        scheduleRefresh()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (now - lastSpace < 350 && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0)       // "word " -> "word. "
            ic.commitText(". ", 1)
            revert = null
        } else {
            finishWord()                          // accepts an active autocorrect pill
            ic.commitText(" ", 1)
        }
        lastSpace = now
        scheduleRefresh()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        finishWord()
        val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
            action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        scheduleRefresh()
    }

    override fun onGlobe(long: Boolean) {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (long) { imm.showInputMethodPicker(); return }
        switchKeyboard(imm)
    }

    @Suppress("DEPRECATION")
    private fun switchKeyboard(imm: InputMethodManager) {
        val token = window?.window?.attributes?.token
        if (token == null || !imm.switchToNextInputMethod(token, false)) imm.showInputMethodPicker()
    }

    override fun onMic() = toggleVoice()

    override fun onMoveCursor(dx: Int, dy: Int) {
        repeat(abs(dx)) {
            sendDownUpKeyEvents(if (dx > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT)
        }
        repeat(abs(dy)) {
            sendDownUpKeyEvents(if (dy > 0) KeyEvent.KEYCODE_DPAD_DOWN else KeyEvent.KEYCODE_DPAD_UP)
        }
        scheduleRefresh()
    }

    override fun onSwipe(path: String) {
        val ic = currentInputConnection ?: return
        if (isPasswordField()) return
        val w = engine.swipe(path) ?: return
        val v = kb
        val shiftState = v?.shift ?: 0
        val cased = when {
            shiftState == 2 -> w.uppercase()
            shiftState == 1 || w == "i" || w.startsWith("i'") -> w.replaceFirstChar { it.uppercase() }
            else -> w
        }
        val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
        val lead = if (before.isNotEmpty() && (before[0].isLetterOrDigit() || before[0] in ".,;:!?")) " " else ""
        revert = null
        ic.commitText("$lead$cased ", 1)
        val (_, prev, _) = wordContext()
        engine.learn(prev, w)
        scheduleRefresh()
    }

    override fun onBarTap(slot: Int) {
        val b = kb?.bar ?: return
        when (slot) {
            0 -> when {
                b.revert -> doRevert()
                b.literal -> applyLiteral()
                else -> applyWord(b.left)
            }
            1 -> applyWord(b.center)
            2 -> if (b.chip) doTranslate() else applyWord(b.right)
        }
    }

    // ---------------------------------------------------------------- word context / autocorrect

    private fun isPasswordField(): Boolean {
        val t = currentInputEditorInfo?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    private fun wordContext(): Triple<String, String?, String> {
        val before = currentInputConnection?.getTextBeforeCursor(60, 0)?.toString() ?: ""
        val prefix = Regex("[\\p{L}'’]+$").find(before)?.value ?: ""
        val rest = before.substring(0, before.length - prefix.length)
        val prev = Regex("([\\p{L}'’]+)\\s*$").find(rest)?.groupValues?.get(1)
        return Triple(prefix, prev, before)
    }

    private fun recase(w: String, prefix: String): String {
        if (prefix.length > 1 && prefix.all { it.isUpperCase() } && w.length > 1 && !w.contains(' ')) return w.uppercase()
        return if (prefix.firstOrNull()?.isUpperCase() == true) w.replaceFirstChar { it.uppercase() } else w
    }

    private fun cased(w: String, prefix: String): String {
        if (w.isEmpty()) return w
        val cap = prefix.firstOrNull()?.isUpperCase() == true || (prefix.isEmpty() && (kb?.shift ?: 0) != 0)
        return if (w == "i" || w.startsWith("i'") || cap) w.replaceFirstChar { it.uppercase() } else w
    }

    /** Applies an autocorrection if one is pending, otherwise learns the word. */
    private fun finishWord() {
        val ic = currentInputConnection ?: return
        if (isPasswordField()) return
        val (prefix, prev, _) = wordContext()
        if (prefix.isEmpty()) return
        val corr = if (prefs.autoCorrect) engine.correction(prefix) else null
        if (corr != null) {
            val fixed = recase(corr, prefix)
            ic.beginBatchEdit()
            ic.deleteSurroundingText(prefix.length, 0)
            ic.commitText(fixed, 1)
            ic.endBatchEdit()
            revert = Revert(prefix, fixed)
        } else if (prefix.length >= 2) {
            engine.learn(prev, prefix)
        }
    }

    private fun doRevert() {
        val r = revert ?: return
        val ic = currentInputConnection ?: return
        val tail = r.fixed + " "
        val before = ic.getTextBeforeCursor(tail.length, 0)?.toString() ?: ""
        if (before == tail) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(tail.length, 0)
            ic.commitText(r.orig + " ", 1)
            ic.endBatchEdit()
        }
        engine.learn(null, r.orig); engine.learn(null, r.orig)   // stop correcting this word
        revert = null
        scheduleRefresh()
    }

    private fun applyLiteral() {
        val ic = currentInputConnection ?: return
        val (prefix, prev, _) = wordContext()
        if (prefix.isEmpty()) return
        engine.learn(prev, prefix); engine.learn(prev, prefix)
        ic.commitText(" ", 1)
        scheduleRefresh()
    }

    private fun applyWord(word: String) {
        if (word.isEmpty()) return
        val ic = currentInputConnection ?: return
        val (prefix, prev, _) = wordContext()
        revert = null
        ic.beginBatchEdit()
        ic.deleteSurroundingText(prefix.length, 0)
        ic.commitText("$word ", 1)
        ic.endBatchEdit()
        if (!isPasswordField()) engine.learn(prev, word)
        scheduleRefresh()
    }

    // ---------------------------------------------------------------- refresh / QuickType bar

    private val refreshRunnable = Runnable { autoCap(); updateSuggestions(); detectLanguage() }

    private fun scheduleRefresh() {
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 40)
    }

    private fun autoCap() {
        val v = kb ?: return
        if (!prefs.autoCap || v.shift == 2 || v.mode != 0) return
        val ei = currentInputEditorInfo ?: return
        val caps = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        v.shift = if (caps != 0) 1 else 0
    }

    private fun updateSuggestions() {
        val v = kb ?: return
        if (isPasswordField()) {
            lastPrefix = ""; lastCands = emptyList(); lastCorr = null
            renderBar()
            return
        }
        val (prefix, prev, before) = wordContext()
        val offline = engine.suggest(prev, prefix)
        val corr = if (prefix.isNotEmpty() && prefs.autoCorrect) engine.correction(prefix) else null
        lastPrefix = prefix; lastCands = offline; lastCorr = corr
        renderBar()

        cloudJob?.let { handler.removeCallbacks(it) }
        val token = ++suggestToken
        if (!prefs.cloud || before.isBlank() || !CloudSuggest.online(this)) return
        val ctxWords = before.trim().split(Regex("\\s+")).takeLast(3).joinToString(" ")
        val endsSpace = before.endsWith(" ")
        val job = Runnable {
            io.execute {
                if (token != suggestToken) return@execute
                val res = CloudSuggest.fetch(ctxWords, endsSpace)
                handler.post {
                    if (token == suggestToken && res.isNotEmpty()) {
                        lastCands = (res.filter { !it.equals(prefix, true) } + offline).distinct().take(3)
                        renderBar()
                    }
                }
            }
        }
        cloudJob = job
        handler.postDelayed(job, 120)
        v.invalidate()
    }

    /** iOS QuickType layout: [ "literal" | centre candidate | right candidate ]. */
    private fun renderBar() {
        val v = kb ?: return
        val b = v.bar
        val prefix = lastPrefix
        b.left = ""; b.center = ""; b.right = ""
        b.pill = false; b.literal = false; b.revert = false; b.chip = false
        val list = lastCands.filter { !it.equals(prefix, true) }
        if (prefix.isNotEmpty()) {
            b.literal = true
            b.left = prefix
            val corr = lastCorr
            if (corr != null) {
                b.center = recase(corr, prefix)
                b.pill = true
                b.right = list.getOrNull(0)?.let { cased(it, prefix) } ?: ""
            } else {
                b.center = list.getOrNull(0)?.let { cased(it, prefix) } ?: ""
                b.right = list.getOrNull(1)?.let { cased(it, prefix) } ?: ""
            }
        } else {
            b.center = list.getOrNull(0)?.let { cased(it, prefix) } ?: ""
            b.left = list.getOrNull(1)?.let { cased(it, prefix) } ?: ""
            b.right = list.getOrNull(2)?.let { cased(it, prefix) } ?: ""
            revert?.let { b.revert = true; b.left = it.orig }
        }
        detectedLang?.let {
            b.chip = true
            b.right = "🌐 " + Locale.forLanguageTag(it).getDisplayLanguage(Locale.ENGLISH) + " → English"
        }
        v.invalidate()
    }

    // ---------------------------------------------------------------- translate to English

    private fun detectLanguage() {
        val ic = currentInputConnection ?: return
        if (isPasswordField()) { showTranslate(null); return }
        val txt = ((ic.getTextBeforeCursor(500, 0) ?: "").toString() + (ic.getTextAfterCursor(500, 0) ?: "")).trim()
        if (txt.length < 12) { showTranslate(null); return }
        translator.detect(txt) { code ->
            val base = code.substringBefore('-')
            if (base == "und" || base == "en") showTranslate(null) else showTranslate(base)
        }
    }

    private fun showTranslate(code: String?) {
        detectedLang = code
        renderBar()
    }

    private fun doTranslate() {
        val code = detectedLang ?: return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(2000, 0)?.toString() ?: ""
        val after = ic.getTextAfterCursor(2000, 0)?.toString() ?: ""
        if ((before + after).isBlank()) return
        kb?.bar?.right = "Translating…"
        kb?.invalidate()
        translator.translate(before + after, code, { out ->
            currentInputConnection?.let {
                it.beginBatchEdit()
                it.deleteSurroundingText(before.length, after.length)
                it.commitText(out, 1)
                it.endBatchEdit()
            }
            showTranslate(null)
            scheduleRefresh()
        }, {
            Toast.makeText(
                this, "Couldn't translate. Connect to the internet once to download the language pack.",
                Toast.LENGTH_LONG
            ).show()
            showTranslate(code)
        })
    }

    // ---------------------------------------------------------------- voice typing

    private fun toggleVoice() { if (listening) stopVoice() else startVoice() }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Allow microphone access to use voice typing", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(this, SettingsActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("ask_mic", true)
            )
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "No speech recognition service on this device", Toast.LENGTH_LONG).show()
            return
        }
        listening = true
        kb?.micOn = true
        beginRecognition()
    }

    private fun beginRecognition() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { stopVoice() }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) currentInputConnection?.setComposingText(t, 1)
            }
            override fun onResults(results: Bundle?) {
                var t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (!t.isNullOrBlank()) {
                    val ei = currentInputEditorInfo
                    val cap = ei != null && (currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0) != 0
                    if (cap) t = t.replaceFirstChar { it.uppercase() }
                    currentInputConnection?.commitText("$t ", 1)
                }
                scheduleRefresh()
                if (listening) handler.post { beginRecognition() }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            if (prefs.voiceLang.isNotEmpty()) putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.voiceLang)
        }
        r.startListening(i)
    }

    private fun stopVoice() {
        val was = listening
        listening = false
        recognizer?.destroy()
        recognizer = null
        if (was) currentInputConnection?.finishComposingText()
        kb?.micOn = false
    }
}
