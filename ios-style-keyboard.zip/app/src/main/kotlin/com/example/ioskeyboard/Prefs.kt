package com.example.ioskeyboard

import android.content.Context
import android.content.res.Configuration

class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("kb", Context.MODE_PRIVATE)

    var theme: String
        get() = sp.getString("theme", "system") ?: "system"
        set(v) = sp.edit().putString("theme", v).apply()
    var sound: Boolean
        get() = sp.getBoolean("sound", true)
        set(v) = sp.edit().putBoolean("sound", v).apply()
    var soundClip: Boolean
        get() = sp.getBoolean("soundclip", true)
        set(v) = sp.edit().putBoolean("soundclip", v).apply()
    var haptic: Boolean
        get() = sp.getBoolean("haptic", true)
        set(v) = sp.edit().putBoolean("haptic", v).apply()
    var cloud: Boolean
        get() = sp.getBoolean("cloud", true)
        set(v) = sp.edit().putBoolean("cloud", v).apply()
    var autoCap: Boolean
        get() = sp.getBoolean("autocap", true)
        set(v) = sp.edit().putBoolean("autocap", v).apply()
    var autoCorrect: Boolean
        get() = sp.getBoolean("autocorrect", true)
        set(v) = sp.edit().putBoolean("autocorrect", v).apply()
    var heightPct: Int
        get() = sp.getInt("height", 100)
        set(v) = sp.edit().putInt("height", v).apply()
    var oneHanded: String
        get() = sp.getString("onehanded", "off") ?: "off"
        set(v) = sp.edit().putString("onehanded", v).apply()
    var voiceLang: String
        get() = sp.getString("voicelang", "") ?: ""
        set(v) = sp.edit().putString("voicelang", v).apply()

    fun isDark(): Boolean = when (theme) {
        "dark" -> true
        "light" -> false
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    /** Changes to any of these require the keyboard view to be rebuilt. */
    fun signature() = "$theme|$heightPct|$oneHanded|${isDark()}"
}
