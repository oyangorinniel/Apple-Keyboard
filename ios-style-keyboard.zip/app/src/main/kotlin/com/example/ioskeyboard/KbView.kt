package com.example.ioskeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.SparseArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/** What the QuickType bar shows. */
class BarModel {
    var left = ""
    var center = ""
    var right = ""
    var pill = false      // centre slot is an active autocorrection (press Space to accept)
    var literal = false   // left slot is the quoted literal being typed
    var revert = false    // left slot is "return to original" (blue underline)
    var chip = false      // right slot is the translate chip
}

interface KbHost {
    fun onChar(s: String)
    fun onBackspace(word: Boolean)
    fun onSpace()
    fun onEnter()
    fun onGlobe(long: Boolean)
    fun onMic()
    fun onSwipe(path: String)
    fun onBarTap(slot: Int)
    fun onMoveCursor(dx: Int, dy: Int)
    fun onSound(kind: Int)   // 0 click, 1 delete, 2 modifier
    fun onHaptic()
}

/**
 * The whole keyboard (QuickType bar, 4 key rows, bottom dock) drawn on one canvas, so key pop-ups
 * can overlap the bar exactly like iOS, and gestures (slide-to-type, swipe, trackpad) are possible.
 */
class KbView(ctx: Context, private val host: KbHost) : View(ctx) {

    companion object {
        const val CHAR = 0
        const val SHIFT = 1
        const val DEL = 2
        const val MODE = 3
        const val SPACE = 4
        const val RETURN = 5

        private val VARIANTS: Map<String, List<String>> = mapOf(
            "a" to listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā"),
            "e" to listOf("è", "é", "ê", "ë", "ē", "ė", "ę"),
            "i" to listOf("î", "ï", "í", "ī", "į", "ì"),
            "o" to listOf("ô", "ö", "ò", "ó", "œ", "ø", "ō", "õ"),
            "u" to listOf("û", "ü", "ù", "ú", "ū"),
            "y" to listOf("ÿ", "ý"),
            "n" to listOf("ñ", "ń"),
            "c" to listOf("ç", "ć", "č"),
            "s" to listOf("ß", "ś", "š"),
            "z" to listOf("ž", "ź", "ż"),
            "l" to listOf("ł"),
            "-" to listOf("–", "—", "•"),
            "." to listOf("…"),
            "$" to listOf("₩", "¥", "€", "£", "¢"),
            "0" to listOf("°"),
            "?" to listOf("¿"),
            "!" to listOf("¡"),
            "%" to listOf("‰"),
            "'" to listOf("‘", "’", "`"),
            "\"" to listOf("“", "”", "„", "«", "»")
        )
    }

    private class Key(val type: Int, val label: String, val target: Int = 0) {
        val r = RectF()
    }

    private class TP(val x: Float, val y: Float, val t: Long)

    private class Ptr {
        var key: Key? = null
        var start: Key? = null
        var downX = 0f
        var downY = 0f
        var lastX = 0f
        var lastY = 0f
        var accX = 0f
        var accY = 0f
        var barSlot = -1
        var dock = 0
        var swiping = false
        var trackpad = false
        var variants: List<String>? = null
        var sel = 0
        val vRect = RectF()
        var slideMode = false
        var savedMode = 0
        var savedShift = 0
        var longFired = false
        var longRun: Runnable? = null
        val trail = ArrayList<TP>()
        val path = StringBuilder()
    }

    // ------------------------------------------------------------------ public state
    val bar = BarModel()

    var micOn = false
        set(v) { field = v; invalidate() }

    /** 0 = off, 1 = single-cap, 2 = caps lock */
    var shift = 0
        set(v) { if (field != v) { field = v; invalidate() } }

    /** 0 = letters, 1 = numbers, 2 = symbols */
    var mode = 0
        private set

    fun setMode(m: Int) {
        mode = m
        layoutKeys()
        invalidate()
    }

    fun configure(dark: Boolean, heightPct: Int, oneHanded: String) {
        heightScale = heightPct / 100f
        this.oneHanded = oneHanded
        if (dark) {
            cBase = col("#1C1C1E"); cKey = col("#3A3A3C"); cMod = col("#2C2C2E"); cText = Color.WHITE
            cShadow = col("#99000000"); cPop = col("#636366"); cActive = col("#F2F2F7"); cDiv = col("#55FFFFFF")
        } else {
            cBase = col("#D1D3D9"); cKey = Color.WHITE; cMod = col("#ACB3BF"); cText = Color.BLACK
            cShadow = col("#52000000"); cPop = Color.WHITE; cActive = Color.WHITE; cDiv = col("#40000000")
        }
    }

    // ------------------------------------------------------------------ internals
    private val d = resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private val keys = ArrayList<Key>()
    private val ptrs = SparseArray<Ptr>()
    private val fadingKeys = ArrayList<Key>()
    private val fadingTrails = ArrayList<ArrayList<TP>>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    private var heightScale = 1f
    private var oneHanded = "off"
    private var cBase = 0; private var cKey = 0; private var cMod = 0; private var cText = 0
    private var cShadow = 0; private var cPop = 0; private var cActive = 0; private var cDiv = 0
    private val blue = col("#0A84FF")
    private var kw = 0f
    private var lastShiftTap = 0L

    private fun col(s: String) = Color.parseColor(s)

    private val gap get() = 6f * d
    private val side get() = 3f * d
    private val barH get() = 44f * d
    private val topPad get() = 12f * d
    private val keyH get() = 42f * d * heightScale
    private val rowGap get() = 11f * d * heightScale
    private val dockH get() = 44f * d
    private val usable get() = if (oneHanded == "off") width.toFloat() else width * 0.82f
    private val xOff get() = if (oneHanded == "right") width - usable else 0f

    private fun rowTop(r: Int) = barH + topPad + r * (keyH + rowGap)
    private fun totalH() = (barH + topPad + 4 * keyH + 3 * rowGap + dockH).roundToInt()
    private fun dockTop() = rowTop(3) + keyH + rowGap * 0.5f

    override fun onMeasure(w: Int, h: Int) {
        var width = MeasureSpec.getSize(w)
        if (width == 0) width = resources.displayMetrics.widthPixels
        setMeasuredDimension(width, totalH())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutKeys()
    }

    // ------------------------------------------------------------------ layout
    private fun layoutKeys() {
        keys.clear()
        if (width == 0) return
        val u = usable
        val x0 = xOff
        kw = (u - 2 * side - 9 * gap) / 10f
        val util = max(42f * d, kw * 1.3f)
        val first = x0 + side
        val step = kw + gap

        fun addChars(row: Int, s: String, sx: Float, w: Float, st: Float) {
            for (i in s.indices) {
                val k = Key(CHAR, s[i].toString())
                val l = sx + i * st
                k.r.set(l, rowTop(row), l + w, rowTop(row) + keyH)
                keys.add(k)
            }
        }

        fun addKey(type: Int, label: String, target: Int, row: Int, l: Float, w: Float) {
            val k = Key(type, label, target)
            k.r.set(l, rowTop(row), l + w, rowTop(row) + keyH)
            keys.add(k)
        }

        if (mode == 0) {
            addChars(0, "qwertyuiop", first, kw, step)
            addChars(1, "asdfghjkl", x0 + (u - (9 * kw + 8 * gap)) / 2f, kw, step)
            val bg = (u - 2 * side - 2 * util - 7 * kw - 6 * gap) / 2f
            addKey(SHIFT, "", 0, 2, first, util)
            addChars(2, "zxcvbnm", first + util + bg, kw, step)
            addKey(DEL, "", 0, 2, x0 + u - side - util, util)
        } else {
            addChars(0, if (mode == 1) "1234567890" else "[]{}#%^*+=", first, kw, step)
            addChars(1, if (mode == 1) "-/:;()$&@\"" else "_\\|~<>€£¥•", first, kw, step)
            val bg = 12f * d
            val wk = (u - 2 * side - 2 * util - 2 * bg - 4 * gap) / 5f
            if (mode == 1) addKey(MODE, "#+=", 2, 2, first, util) else addKey(MODE, "123", 1, 2, first, util)
            addChars(2, ".,?!'", first + util + bg, wk, wk + gap)
            addKey(DEL, "", 0, 2, x0 + u - side - util, util)
        }
        val avail = u - 2 * side - 2 * gap
        val wm = avail * 0.24f
        addKey(MODE, if (mode == 0) "123" else "ABC", if (mode == 0) 1 else 0, 3, first, wm)
        addKey(SPACE, "space", 0, 3, first + wm + gap, avail - 2 * wm)
        addKey(RETURN, "return", 0, 3, first + (u - 2 * side) - wm, wm)
    }

    private fun keyAt(x: Float, y: Float): Key? {
        var best: Key? = null
        var bd = Float.MAX_VALUE
        for (k in keys) {
            val dx = max(max(k.r.left - x, 0f), x - k.r.right)
            val dy = max(max(k.r.top - y, 0f), y - k.r.bottom)
            val dd = dx * dx + dy * dy
            if (dd < bd) { bd = dd; best = k }
        }
        return best
    }

    private fun display(k: Key): String =
        if (k.type == CHAR && mode == 0 && shift != 0) k.label.uppercase() else k.label

    private fun trackpadActive(): Boolean {
        for (i in 0 until ptrs.size()) if (ptrs.valueAt(i).trackpad) return true
        return false
    }

    // ------------------------------------------------------------------ drawing
    override fun onDraw(c: Canvas) {
        c.drawColor(cBase)
        drawBar(c)
        val fade = trackpadActive()
        for (k in keys) drawKey(c, k, fade)
        drawDock(c)
        drawTrails(c)
        drawPopups(c)
    }

    private fun label(c: Canvas, t: String, r: RectF, size: Float, color: Int) {
        textPaint.color = color
        textPaint.textSize = size * d
        val fm = textPaint.fontMetrics
        c.drawText(t, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    private fun drawKey(c: Canvas, k: Key, fade: Boolean) {
        var pressed = false
        for (i in 0 until ptrs.size()) if (ptrs.valueAt(i).key === k) pressed = true
        val special = k.type != CHAR && k.type != SPACE
        var fill = if (special) cMod else cKey
        if (k.type == SHIFT && shift != 0) fill = cActive
        else if (pressed && special) fill = cKey
        else if (pressed && k.type == SPACE) fill = cMod
        val rr = 5f * d
        paint.style = Paint.Style.FILL
        paint.color = cShadow
        c.drawRoundRect(k.r.left, k.r.top + d, k.r.right, k.r.bottom + d, rr, rr, paint)
        paint.color = fill
        paint.alpha = if (fade) 150 else 255
        c.drawRoundRect(k.r, rr, rr, paint)
        paint.alpha = 255
        if (fade) return
        val tc = if (k.type == SHIFT && shift != 0) Color.BLACK else cText
        when (k.type) {
            CHAR -> label(c, display(k), k.r, 23f, tc)
            MODE -> label(c, k.label, k.r, 16f, tc)
            SPACE -> label(c, "space", k.r, 16f, tc)
            RETURN -> label(c, "return", k.r, 16f, tc)
            SHIFT -> drawShift(c, k.r)
            DEL -> drawDelete(c, k.r)
        }
    }

    private fun drawShift(c: Canvas, r: RectF) {
        val cx = r.centerX()
        val cy = r.centerY() - d
        val p = Path()
        p.moveTo(cx, cy - 9f * d)
        p.lineTo(cx + 10f * d, cy + 1f * d)
        p.lineTo(cx + 4.5f * d, cy + 1f * d)
        p.lineTo(cx + 4.5f * d, cy + 8f * d)
        p.lineTo(cx - 4.5f * d, cy + 8f * d)
        p.lineTo(cx - 4.5f * d, cy + 1f * d)
        p.lineTo(cx - 10f * d, cy + 1f * d)
        p.close()
        paint.color = if (shift != 0) Color.BLACK else cText
        paint.style = if (shift == 0) Paint.Style.STROKE else Paint.Style.FILL
        paint.strokeWidth = 1.6f * d
        paint.strokeJoin = Paint.Join.ROUND
        c.drawPath(p, paint)
        if (shift == 2) {
            paint.style = Paint.Style.FILL
            c.drawRect(cx - 4.5f * d, cy + 10f * d, cx + 4.5f * d, cy + 12f * d, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawDelete(c: Canvas, r: RectF) {
        val cx = r.centerX()
        val cy = r.centerY()
        val p = Path()
        p.moveTo(cx - 11f * d, cy)
        p.lineTo(cx - 5f * d, cy - 8f * d)
        p.lineTo(cx + 11f * d, cy - 8f * d)
        p.lineTo(cx + 11f * d, cy + 8f * d)
        p.lineTo(cx - 5f * d, cy + 8f * d)
        p.close()
        paint.color = cText
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.6f * d
        paint.strokeJoin = Paint.Join.ROUND
        c.drawPath(p, paint)
        c.drawLine(cx - 1.5f * d, cy - 3.5f * d, cx + 6f * d, cy + 3.5f * d, paint)
        c.drawLine(cx + 6f * d, cy - 3.5f * d, cx - 1.5f * d, cy + 3.5f * d, paint)
        paint.style = Paint.Style.FILL
    }

    private fun drawDock(c: Canvas) {
        val cy = rowTop(3) + keyH + dockH / 2f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.6f * d
        paint.color = cText
        paint.alpha = 220
        // globe (bottom-left)
        val gx = xOff + 30f * d
        c.drawCircle(gx, cy, 9f * d, paint)
        c.drawOval(RectF(gx - 4f * d, cy - 9f * d, gx + 4f * d, cy + 9f * d), paint)
        c.drawLine(gx - 9f * d, cy, gx + 9f * d, cy, paint)
        c.drawLine(gx, cy - 9f * d, gx, cy + 9f * d, paint)
        // microphone (bottom-right)
        val mx = xOff + usable - 30f * d
        if (micOn) { paint.color = col("#FF3B30"); paint.alpha = 255 }
        val cap = RectF(mx - 3.5f * d, cy - 10f * d, mx + 3.5f * d, cy + 2f * d)
        paint.style = if (micOn) Paint.Style.FILL else Paint.Style.STROKE
        c.drawRoundRect(cap, 3.5f * d, 3.5f * d, paint)
        paint.style = Paint.Style.STROKE
        c.drawArc(RectF(mx - 7f * d, cy - 6f * d, mx + 7f * d, cy + 8f * d), 0f, 180f, false, paint)
        c.drawLine(mx, cy + 8f * d, mx, cy + 11f * d, paint)
        paint.alpha = 255
        paint.style = Paint.Style.FILL
    }

    private fun slotText(c: Canvas, t: String, slot: Int, color: Int, underline: Boolean) {
        if (t.isEmpty()) return
        val w3 = width / 3f
        textPaint.textSize = 17f * d
        textPaint.color = color
        val s = TextUtils.ellipsize(t, android.text.TextPaint(textPaint), w3 - 16f * d, TextUtils.TruncateAt.END).toString()
        val cx = w3 * slot + w3 / 2f
        val fm = textPaint.fontMetrics
        val y = barH / 2f - (fm.ascent + fm.descent) / 2f
        c.drawText(s, cx, y, textPaint)
        if (underline) {
            val half = textPaint.measureText(s) / 2f
            paint.color = blue
            paint.style = Paint.Style.FILL
            c.drawRect(cx - half, y + 3f * d, cx + half, y + 4.5f * d, paint)
        }
    }

    private fun drawBar(c: Canvas) {
        val w3 = width / 3f
        paint.style = Paint.Style.FILL
        if (bar.pill && bar.center.isNotEmpty()) {
            paint.color = cKey
            c.drawRoundRect(RectF(w3 + 6f * d, 5f * d, 2 * w3 - 6f * d, barH - 5f * d), 8f * d, 8f * d, paint)
        } else {
            paint.color = cDiv
            c.drawRect(w3, barH / 2f - 11f * d, w3 + d, barH / 2f + 11f * d, paint)
            c.drawRect(2 * w3, barH / 2f - 11f * d, 2 * w3 + d, barH / 2f + 11f * d, paint)
        }
        val leftText = if (bar.literal) "“" + bar.left + "”" else bar.left
        slotText(c, leftText, 0, if (bar.revert) blue else cText, bar.revert)
        slotText(c, bar.center, 1, cText, false)
        if (bar.chip && bar.right.isNotEmpty()) {
            paint.color = blue
            c.drawRoundRect(RectF(2 * w3 + 6f * d, 7f * d, 3 * w3 - 6f * d, barH - 7f * d), 15f * d, 15f * d, paint)
            slotText(c, bar.right, 2, Color.WHITE, false)
        } else {
            slotText(c, bar.right, 2, cText, false)
        }
    }

    private fun drawPopups(c: Canvas) {
        if (!trackpadActive()) {
            for (i in 0 until ptrs.size()) {
                val p = ptrs.valueAt(i)
                val v = p.variants
                if (v != null) { drawVariants(c, p, v); continue }
                val k = p.key ?: continue
                if (k.type == CHAR && !p.swiping && p.barSlot < 0 && p.dock == 0) drawPop(c, k)
            }
            for (k in fadingKeys) drawPop(c, k)
        }
    }

    /** iOS-style teardrop callout: enlarged key cap above the finger, joined to the key by a neck. */
    private fun drawPop(c: Canvas, k: Key) {
        val pw = k.r.width() + 20f * d
        val left = k.r.centerX().coerceIn(pw / 2f + 2f * d, width - pw / 2f - 2f * d) - pw / 2f
        val top = k.r.top - 50f * d
        val bottom = k.r.top - 2f * d
        val body = RectF(left, top, left + pw, bottom)
        val path = Path()
        path.addRoundRect(body, 10f * d, 10f * d, Path.Direction.CW)
        val neck = Path()
        neck.addRoundRect(RectF(k.r.left, bottom - 14f * d, k.r.right, k.r.bottom), 5f * d, 5f * d, Path.Direction.CW)
        path.op(neck, Path.Op.UNION)
        paint.style = Paint.Style.FILL
        paint.color = cShadow
        c.save(); c.translate(0f, 1.5f * d); c.drawPath(path, paint); c.restore()
        paint.color = cPop
        c.drawPath(path, paint)
        val r = RectF(body.left, body.top, body.right, body.bottom - 8f * d)
        label(c, display(k), r, 34f, cText)
    }

    private fun drawVariants(c: Canvas, p: Ptr, v: List<String>) {
        val r = p.vRect
        paint.style = Paint.Style.FILL
        paint.color = cShadow
        c.drawRoundRect(RectF(r.left, r.top + 1.5f * d, r.right, r.bottom + 1.5f * d), 10f * d, 10f * d, paint)
        paint.color = cPop
        c.drawRoundRect(r, 10f * d, 10f * d, paint)
        val itemW = 36f * d
        for (i in v.indices) {
            val ir = RectF(r.left + 6f * d + i * itemW, r.top + 5f * d, r.left + 6f * d + (i + 1) * itemW, r.bottom - 5f * d)
            if (i == p.sel) {
                paint.color = blue
                c.drawRoundRect(ir, 7f * d, 7f * d, paint)
            }
            label(c, v[i], ir, 24f, if (i == p.sel) Color.WHITE else cText)
        }
    }

    private fun drawTrails(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        var any = false
        fun draw(t: ArrayList<TP>) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f * d
            paint.strokeCap = Paint.Cap.ROUND
            for (i in 1 until t.size) {
                val a = (255 * (1f - (now - t[i].t) / 450f)).toInt()
                if (a > 0) {
                    any = true
                    paint.color = blue
                    paint.alpha = a
                    c.drawLine(t[i - 1].x, t[i - 1].y, t[i].x, t[i].y, paint)
                }
            }
            paint.alpha = 255
            paint.style = Paint.Style.FILL
        }
        for (i in 0 until ptrs.size()) draw(ptrs.valueAt(i).trail)
        for (t in fadingTrails) draw(t)
        fadingTrails.removeAll { it.isEmpty() || now - it.last().t > 450 }
        if (any) postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                up(e.getPointerId(i), e.getX(i), e.getY(i), false)
            }
            MotionEvent.ACTION_CANCEL -> {
                val ids = IntArray(ptrs.size()) { ptrs.keyAt(it) }
                for (id in ids) up(id, 0f, 0f, true)
            }
        }
        return true
    }

    private fun armLong(p: Ptr, ms: Long, action: () -> Unit) {
        val r = Runnable { if (ptrs.indexOfValue(p) >= 0) action() }
        p.longRun = r
        handler.postDelayed(r, ms)
    }

    private fun cancelLong(p: Ptr) {
        p.longRun?.let { handler.removeCallbacks(it) }
        p.longRun = null
    }

    private fun down(id: Int, x: Float, y: Float) {
        val p = Ptr()
        p.downX = x; p.downY = y; p.lastX = x; p.lastY = y
        ptrs.put(id, p)
        if (y < barH) {
            p.barSlot = (x / (width / 3f)).toInt().coerceIn(0, 2)
            host.onSound(0); host.onHaptic()
            return
        }
        if (y > dockTop()) {
            p.dock = if (x < width / 2f) 1 else 2
            host.onSound(2); host.onHaptic()
            if (p.dock == 1) armLong(p, 500) { p.longFired = true; host.onGlobe(true) }
            invalidate()
            return
        }
        val k = keyAt(x, y) ?: return
        p.key = k
        p.start = k
        when (k.type) {
            CHAR -> {
                host.onSound(0); host.onHaptic()
                val list = VARIANTS[k.label]
                if (list != null) armLong(p, 400) { showVariants(p, k, list) }
            }
            DEL -> {
                host.onSound(1); host.onHaptic(); host.onBackspace(false); startDelete()
            }
            SHIFT -> {
                host.onSound(2); host.onHaptic()
                p.slideMode = true; p.savedShift = shift
                shift = 1
            }
            MODE -> {
                host.onSound(2); host.onHaptic()
                p.slideMode = true; p.savedMode = mode
                setMode(k.target)
            }
            SPACE -> {
                host.onSound(2); host.onHaptic()
                armLong(p, 400) {
                    p.trackpad = true
                    p.lastX = p.downX; p.lastY = p.downY
                    host.onHaptic()
                    invalidate()
                }
            }
            RETURN -> { host.onSound(2); host.onHaptic() }
        }
        invalidate()
    }

    private fun showVariants(p: Ptr, k: Key, list: List<String>) {
        val shown = if (mode == 0 && shift != 0) list.map { it.uppercase() } else list
        val itemW = 36f * d
        val w = shown.size * itemW + 12f * d
        val h = 48f * d
        val left = (k.r.centerX() - itemW / 2f - 6f * d).coerceIn(4f * d, width - w - 4f * d)
        val top = max(2f * d, k.r.top - h - 6f * d)
        p.vRect.set(left, top, left + w, top + h)
        p.variants = shown
        p.sel = 0
        host.onHaptic()
        invalidate()
    }

    private fun move(id: Int, x: Float, y: Float) {
        val p = ptrs.get(id) ?: return
        if (p.barSlot >= 0) return
        if (p.dock != 0) {
            if (hypot(x - p.downX, y - p.downY) > 14f * d) cancelLong(p)
            return
        }
        if (p.trackpad) {
            p.accX += x - p.lastX
            p.accY += y - p.lastY
            p.lastX = x; p.lastY = y
            val stepX = 9f * d
            val stepY = 22f * d
            val sx = (p.accX / stepX).toInt()
            val sy = (p.accY / stepY).toInt()
            if (sx != 0 || sy != 0) {
                p.accX -= sx * stepX
                p.accY -= sy * stepY
                host.onMoveCursor(sx, sy)
            }
            return
        }
        val vs = p.variants
        if (vs != null) {
            val idx = ((x - p.vRect.left - 6f * d) / (36f * d)).toInt().coerceIn(0, vs.size - 1)
            if (idx != p.sel) { p.sel = idx; invalidate() }
            return
        }
        val st = p.start ?: return
        val travel = hypot(x - p.downX, y - p.downY)
        if (travel > 10f * d) cancelLong(p)

        if (st.type == CHAR && mode == 0 && !p.slideMode && !p.swiping && travel > kw * 1.5f) {
            val k = keyAt(x, y)
            if (k != null && k.type == CHAR && k !== st) {
                p.swiping = true
                p.path.append(st.label)
                cancelLong(p)
            }
        }
        if (p.swiping) {
            p.trail.add(TP(x, y, SystemClock.uptimeMillis()))
            if (p.trail.size > 90) p.trail.removeAt(0)
            val k = keyAt(x, y)
            if (k != null && k.type == CHAR && p.path.isNotEmpty() && p.path.last().toString() != k.label) {
                p.path.append(k.label)
            }
            invalidate()
            return
        }
        if (st.type == CHAR || p.slideMode) {
            val k = keyAt(x, y)
            if (k != null && k !== p.key) { p.key = k; invalidate() }
        }
    }

    private fun up(id: Int, x: Float, y: Float, cancel: Boolean) {
        val p = ptrs.get(id) ?: return
        cancelLong(p)
        // finish the action while the pointer is still registered, then remove it
        if (p.barSlot >= 0) {
            if (!cancel) host.onBarTap(p.barSlot)
        } else if (p.dock != 0) {
            if (!cancel && !p.longFired) { if (p.dock == 1) host.onGlobe(false) else host.onMic() }
        } else if (p.trackpad) {
            // legends return when the pointer is removed below
        } else {
            finish(p, x, y, cancel)
        }
        ptrs.remove(id)
        if (p.trail.isNotEmpty()) fadingTrails.add(p.trail)
        val k = p.key
        if (k != null && k.type == CHAR && !p.swiping && p.variants == null && !p.trackpad && !cancel) {
            fadingKeys.add(k)
            handler.postDelayed({ fadingKeys.remove(k); invalidate() }, 70)
        }
        invalidate()
    }

    private fun finish(p: Ptr, x: Float, y: Float, cancel: Boolean) {
        val st = p.start ?: return
        if (st.type == DEL) { stopDelete(); return }
        if (cancel) {
            if (p.slideMode) { if (st.type == SHIFT) shift = p.savedShift else setMode(p.savedMode) }
            return
        }
        val vs = p.variants
        if (vs != null) { commitText(vs[p.sel]); return }
        if (p.swiping) {
            host.onSound(0)
            host.onSwipe(p.path.toString())
            if (shift == 1) shift = 0
            return
        }
        if (p.slideMode) {
            val k = keyAt(x, y)
            if (st.type == SHIFT) {
                if (k != null && k.type == CHAR) {
                    commitKey(k)
                    shift = p.savedShift
                } else {
                    val now = SystemClock.uptimeMillis()
                    shift = when {
                        p.savedShift == 2 -> 0
                        now - lastShiftTap < 300 -> 2
                        p.savedShift == 0 -> 1
                        else -> 0
                    }
                    lastShiftTap = now
                }
            } else if (k != null && k.type == CHAR) {
                commitKey(k)
                setMode(p.savedMode)
            }
            return
        }
        when (st.type) {
            CHAR -> { val k = p.key ?: st; if (k.type == CHAR) commitKey(k) }
            SPACE -> { host.onSpace(); if (mode == 1) setMode(0) }
            RETURN -> host.onEnter()
        }
    }

    private fun commitKey(k: Key) = commitText(display(k))

    private fun commitText(s: String) {
        host.onChar(s)
        if (shift == 1 && mode == 0) shift = 0
    }

    // ------------------------------------------------------------------ backspace repeat
    private var delStart = 0L
    private var delActive = false
    private val delRun = object : Runnable {
        override fun run() {
            if (!delActive) return
            val word = SystemClock.uptimeMillis() - delStart > 850   // ~10Hz chars for 500ms, then words
            host.onSound(1)
            host.onBackspace(word)
            handler.postDelayed(this, if (word) 160 else 100)
        }
    }

    private fun startDelete() {
        delStart = SystemClock.uptimeMillis()
        delActive = true
        handler.postDelayed(delRun, 350)
    }

    private fun stopDelete() {
        delActive = false
        handler.removeCallbacks(delRun)
    }

    override fun onDetachedFromWindow() {
        stopDelete()
        super.onDetachedFromWindow()
    }

    fun haptic() = performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
}
