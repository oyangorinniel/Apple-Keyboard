package com.example.ioskeyboard

import android.content.Context
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONArray

/** Offline predictor: built-in word list + words and word pairs learned from the user. */
class SuggestionEngine(ctx: Context) {
    private val words = ArrayList<String>()
    private val rank = HashMap<String, Int>()
    private val uni = HashMap<String, Int>()
    private val bi = HashMap<String, Int>()
    private val sp = ctx.getSharedPreferences("userdict", Context.MODE_PRIVATE)
    private var dirty = 0

    companion object {
        /** Conservative autocorrect: only well-known typos / missing apostrophes. */
        private val TYPOS = mapOf(
            "teh" to "the", "adn" to "and", "taht" to "that", "waht" to "what", "thier" to "their",
            "recieve" to "receive", "definately" to "definitely", "seperate" to "separate",
            "becuase" to "because", "wich" to "which", "whihc" to "which", "freind" to "friend",
            "tommorow" to "tomorrow", "tomorow" to "tomorrow", "untill" to "until", "alot" to "a lot",
            "occured" to "occurred", "beleive" to "believe", "thankyou" to "thank you", "yuo" to "you",
            "dont" to "don't", "cant" to "can't", "wont" to "won't", "didnt" to "didn't",
            "doesnt" to "doesn't", "isnt" to "isn't", "arent" to "aren't", "wasnt" to "wasn't",
            "couldnt" to "couldn't", "wouldnt" to "wouldn't", "shouldnt" to "shouldn't",
            "im" to "I'm", "ive" to "I've", "youre" to "you're", "theyre" to "they're", "thats" to "that's",
            "whats" to "what's", "havent" to "haven't", "hasnt" to "hasn't", "werent" to "weren't"
        )
    }

    init {
        try {
            ctx.assets.open("words_en.txt").bufferedReader().use { r: BufferedReader ->
                r.forEachLine { line ->
                    val t = line.trim()
                    if (t.isNotEmpty()) {
                        if (!rank.containsKey(t)) rank[t] = words.size
                        words.add(t)
                    }
                }
            }
        } catch (_: Exception) {
        }
        parse(sp.getString("uni", "") ?: "", uni)
        parse(sp.getString("bi", "") ?: "", bi)
    }

    private fun parse(s: String, into: HashMap<String, Int>) {
        for (line in s.split('\n')) {
            val i = line.lastIndexOf('\t')
            if (i > 0) line.substring(i + 1).toIntOrNull()?.let { into[line.substring(0, i)] = it }
        }
    }

    private fun dump(m: Map<String, Int>) = m.entries.joinToString("\n") { "${it.key}\t${it.value}" }

    private fun prune(m: HashMap<String, Int>) {
        if (m.size > 6000) {
            val keep = m.entries.sortedByDescending { it.value }.take(4000).map { it.key }.toSet()
            m.keys.retainAll(keep)
        }
    }

    fun save() {
        if (dirty == 0) return
        prune(uni); prune(bi)
        sp.edit().putString("uni", dump(uni)).putString("bi", dump(bi)).apply()
        dirty = 0
    }

    fun learn(prev: String?, word: String) {
        val w = word.lowercase()
        if (w.length < 2) return
        uni[w] = (uni[w] ?: 0) + 1
        if (prev != null) {
            val k = prev.lowercase() + " " + w
            bi[k] = (bi[k] ?: 0) + 1
        }
        if (++dirty >= 5) save()
    }

    /** A confident autocorrection for the typed word, or null to leave it alone. */
    fun correction(prefix: String): String? {
        val p = prefix.lowercase()
        if (p.length < 2 || p.any { it.isDigit() }) return null
        if ((uni[p] ?: 0) >= 2) return null
        TYPOS[p]?.let { return it }
        if (rank.containsKey(p)) return null
        if (p.length >= 3) {
            for (i in 0 until p.length - 1) {
                if (p[i] == p[i + 1]) continue
                val s = p.substring(0, i) + p[i + 1] + p[i] + p.substring(i + 2)
                val r = rank[s]
                if (r != null && r < 400) return s
            }
        }
        return null
    }

    fun suggest(prev: String?, prefix: String): List<String> {
        val p = prefix.lowercase()
        val pv = prev?.lowercase()
        val scores = HashMap<String, Double>()
        fun add(w: String, s: Double) { scores[w] = (scores[w] ?: 0.0) + s }

        if (p.isEmpty()) {
            if (pv != null) {
                for ((k, c) in bi) if (k.startsWith("$pv ")) add(k.substring(pv.length + 1), c * 200.0)
            }
            for (i in 0 until minOf(40, words.size)) add(words[i], 40.0 - i)
        } else {
            for ((i, w) in words.withIndex()) if (w.startsWith(p) && w != p) add(w, 1000.0 - minOf(i, 900))
            for ((w, c) in uni) if (w.startsWith(p) && w != p) add(w, c * 60.0)
            if (pv != null) {
                for ((k, c) in bi) if (k.startsWith("$pv ")) {
                    val w = k.substring(pv.length + 1)
                    if (w.startsWith(p) && w != p) add(w, c * 200.0)
                }
            }
        }
        return scores.entries.sortedByDescending { it.value }.take(3).map { it.key }
    }

    /** Resolve a swipe path (letters under the finger) to the most likely dictionary word. */
    fun swipe(path: String): String? {
        val p = path.lowercase()
        if (p.length < 2) return null
        var best: String? = null
        var bestScore = -1e9
        fun consider(w: String, base: Double) {
            if (w.length < 2 || w[0] != p[0] || w.last() != p.last()) return
            if (!isSubsequence(w, p)) return
            val score = base + w.length * 25.0 - (p.length - w.length).coerceAtLeast(0) * 6.0
            if (score > bestScore) { bestScore = score; best = w }
        }
        for ((i, w) in words.withIndex()) consider(w, 1000.0 - minOf(i, 900))
        for ((w, c) in uni) consider(w, 500.0 + c * 60.0)
        return best
    }

    private fun isSubsequence(w: String, p: String): Boolean {
        var idx = 0
        var prev = ' '
        for (ch in w) {
            if (ch == prev) continue          // double letters share one key
            val j = p.indexOf(ch, idx)
            if (j < 0) return false
            idx = j + 1
            prev = ch
        }
        return true
    }
}

/** Online predictor (Google's public suggest endpoint). Only the last ~3 typed words are sent. */
object CloudSuggest {
    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)
            ?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    fun fetch(context: String, endsWithSpace: Boolean): List<String> {
        return try {
            val q = if (endsWithSpace) "$context " else context
            val url = URL(
                "https://suggestqueries.google.com/complete/search?client=firefox&q=" +
                    URLEncoder.encode(q, "UTF-8")
            )
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 1200
            c.readTimeout = 1200
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val arr = JSONArray(body).getJSONArray(1)
            val n = context.trim().split(Regex("\\s+")).size
            val idx = if (endsWithSpace) n else n - 1
            val out = LinkedHashSet<String>()
            for (i in 0 until arr.length()) {
                val toks = arr.getString(i).split(Regex("\\s+"))
                if (idx < toks.size && toks[idx].isNotBlank()) out.add(toks[idx])
            }
            out.toList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
