package com.example.ioskeyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Synthesizes the three keyboard sounds (click / delete / modifier) once, caches them as WAVs and
 * plays them through a SoundPool (low latency, polyphonic, oldest voice is stolen automatically).
 * Each play gets a +-3% random gain so fast typing sounds organic.
 */
class KeySounds(ctx: Context, useClips: Boolean = true) {
    private val pool: SoundPool
    private val ids = IntArray(3)
    private val base = floatArrayOf(0.85f, 0.75f, 0.95f)
    private val rnd = Random()

    init {
        pool = SoundPool.Builder()
            .setMaxStreams(6)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        val names = arrayOf("key_click.wav", "key_delete.wav", "key_modifier.wav")
        val bundled = ctx.assets.list("")?.toSet() ?: emptySet()
        for (k in 0..2) {
            val f: File
            if (useClips && bundled.contains(names[k])) {
                // sounds cut from the supplied recording (assets/key_*.wav)
                f = File(ctx.cacheDir, "clip_" + names[k])
                ctx.assets.open(names[k]).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            } else {
                f = File(ctx.cacheDir, "key_snd_v1_$k.wav")
                if (!f.exists()) f.writeBytes(wav(synth(k)))
            }
            ids[k] = pool.load(f.absolutePath, 1)
        }
    }

    fun play(kind: Int) {
        val v = base[kind] * (0.97f + rnd.nextFloat() * 0.06f)
        pool.play(ids[kind], v, v, 1, 0, 1f)
    }

    fun release() = pool.release()

    private fun synth(kind: Int): ShortArray {
        val sr = 44100
        val n = (0.10 * sr).toInt()
        val r = Random(7L + kind)
        val noise = DoubleArray(n) { r.nextDouble() * 2 - 1 }

        val f: Double; val q: Double; val tau: Double
        val bodyF: Double; val bodyTau: Double; val bodyAmp: Double
        val hiF: Double; val hiAmp: Double; val attack: Double
        when (kind) {
            0 -> { f = 2100.0; q = 2.5; tau = 0.014; bodyF = 2000.0; bodyTau = 0.007; bodyAmp = 0.45; hiF = 0.0; hiAmp = 0.0; attack = 0.0003 }
            1 -> { f = 1100.0; q = 1.6; tau = 0.022; bodyF = 950.0; bodyTau = 0.020; bodyAmp = 0.55; hiF = 0.0; hiAmp = 0.0; attack = 0.0015 }
            else -> { f = 1100.0; q = 1.8; tau = 0.026; bodyF = 1100.0; bodyTau = 0.030; bodyAmp = 0.60; hiF = 3000.0; hiAmp = 0.5; attack = 0.0004 }
        }

        // RBJ band-pass biquad on the noise burst
        val w0 = 2 * PI * f / sr
        val alpha = sin(w0) / (2 * q)
        val a0 = 1 + alpha
        val b0 = alpha / a0
        val b2 = -alpha / a0
        val a1 = -2 * cos(w0) / a0
        val a2 = (1 - alpha) / a0
        var x1 = 0.0; var x2 = 0.0; var y1 = 0.0; var y2 = 0.0

        val buf = DoubleArray(n)
        var peak = 1e-9
        for (i in 0 until n) {
            val x = noise[i]
            val y = b0 * x + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1; x1 = x; y2 = y1; y1 = y
            val t = i.toDouble() / sr
            val att = if (attack > 0) min(1.0, t / attack) else 1.0
            var s = y * 3.0 * exp(-t / tau) * att
            s += bodyAmp * sin(2 * PI * bodyF * t) * exp(-t / bodyTau) * att
            if (hiF > 0) s += hiAmp * sin(2 * PI * hiF * t) * exp(-t / 0.004)
            buf[i] = s
            if (abs(s) > peak) peak = abs(s)
        }
        val g = 0.9 / peak
        return ShortArray(n) { (buf[it] * g * 32767).toInt().coerceIn(-32768, 32767).toShort() }
    }

    private fun wav(pcm: ShortArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size * 2)
        bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray()); bb.putInt(16)
        bb.putShort(1); bb.putShort(1); bb.putInt(44100); bb.putInt(44100 * 2)
        bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size * 2)
        for (s in pcm) bb.putShort(s)
        return bb.array()
    }
}
